"""
live_monitor.py — periodically reloads an authorized local CSV/JSON/JSONL/
SQLite source and refreshes the app's working dataset. Ported from the CLI
tool's LiveMonitor class; adapted to update shared state instead of a
Tkinter callback so the Flask app can poll its status over HTTP.

It does NOT access a phone or intercept communications — it only re-reads
a file the user has pointed it at.
"""

import os
import threading
import time

import core

_lock = threading.Lock()
_state = {
    "running": False,
    "source_path": None,
    "table_name": None,
    "interval": 5,
    "last_update": None,
    "last_error": None,
    "record_count": 0,
    "alert_count": 0,
}
_thread = None
_last_signature = None


def get_status():
    with _lock:
        return dict(_state)


def _signature(path):
    try:
        stat = os.stat(path)
        return (stat.st_size, stat.st_mtime_ns)
    except OSError:
        return None


def _loop(source_path, table_name, interval):
    global _last_signature
    while True:
        with _lock:
            if not _state["running"]:
                return
        signature = _signature(source_path)

        if signature != _last_signature:
            _last_signature = signature
            try:
                df = core.load_data(source_path, table_name=table_name)
                core.save_current_dataframe(df)
                anomalies = core.detect_anomalies(df)
                with _lock:
                    _state["record_count"] = len(df)
                    _state["alert_count"] = len(anomalies)
                    _state["last_update"] = time.strftime("%Y-%m-%d %H:%M:%S")
                    _state["last_error"] = None
            except Exception as exc:
                with _lock:
                    _state["last_error"] = str(exc)

        time.sleep(interval)


def start(source_path, interval=5, table_name=None):
    global _thread, _last_signature
    stop()
    _last_signature = None

    with _lock:
        _state["running"] = True
        _state["source_path"] = source_path
        _state["table_name"] = table_name
        _state["interval"] = max(1, int(interval))
        _state["last_error"] = None

    _thread = threading.Thread(
        target=_loop, args=(source_path, table_name, max(1, int(interval))), daemon=True
    )
    _thread.start()
    core.add_audit_log("LIVE_MONITOR_START", source_path)


def stop():
    with _lock:
        was_running = _state["running"]
        _state["running"] = False
        source_path = _state["source_path"]
    if was_running:
        core.add_audit_log("LIVE_MONITOR_STOP", source_path or "")
