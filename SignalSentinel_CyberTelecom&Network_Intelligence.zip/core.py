"""
core.py — Telecom Signal & Cyber-Network Security Intelligence Engine

Engineered for Mobile Network Security, RF Spectrum Intelligence, Cell Site Benchmarking,
and Anomaly Threat Detection. Provides robust multi-schema ingestion, statistical signal modeling,
GPS geo-mapping, simulated drive-test synthesis, SQLite encryption storage, and executive security reports.
"""

import os
import re
import json
import math
import random
import sqlite3
from datetime import datetime, timedelta
from pathlib import Path

import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
LOGS_DIR = os.path.join(BASE_DIR, "logs")
SAMPLE_DIR = os.path.join(BASE_DIR, "sample_data")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)
os.makedirs(SAMPLE_DIR, exist_ok=True)

DATA_FILE = os.path.join(DATA_DIR, "call_data.csv")
DB_FILE = os.path.join(DATA_DIR, "tracker.db")
AUDIT_FILE = os.path.join(LOGS_DIR, "audit.log")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

APP_NAME = "Cyber Telecom & Network Intelligence Suite"
APP_BRAND = "SignalSentinel"
APP_VERSION = "4.0 CyberOps"


# ================================================================
# GENERIC COLUMN DETECTION & CANONICALIZATION
# ================================================================

COLUMN_ALIASES = {
    "timestamp": [
        "timestamp", "time", "datetime", "date_time", "date",
        "event_time", "call_time", "created_at", "recorded_at", "ts"
    ],
    "call_type": [
        "call_type", "type", "direction", "call_direction",
        "event_type", "call_status", "status"
    ],
    "phone_number": [
        "phone_number", "phone", "number", "msisdn", "caller",
        "caller_number", "callee", "callee_number", "contact", "peer_number"
    ],
    "duration": [
        "duration", "duration_sec", "duration_seconds", "call_duration",
        "seconds", "length", "duration_s"
    ],
    "cell_id": [
        "cell_id", "cellid", "cell", "eci", "ecid", "enodeb",
        "enodeb_id", "gnodeb", "gnodeb_id", "cgi", "ci", "tower_id"
    ],
    "lac": ["lac", "location_area_code", "tac", "tracking_area_code", "area_code"],
    "mcc": ["mcc", "mobile_country_code"],
    "mnc": ["mnc", "mobile_network_code"],
    "radio_type": [
        "radio_type", "network_type", "network", "technology",
        "radio", "rat", "access_technology", "tech", "generation"
    ],
    "rsrp": [
        "rsrp", "signal_strength", "signal", "signal_dbm",
        "rsrp_dbm", "reference_signal_received_power", "dbm", "rssi"
    ],
    "latitude": ["latitude", "lat", "geo_lat", "y"],
    "longitude": ["longitude", "lon", "lng", "geo_lon", "x"],
}


def normalize_name(name):
    return re.sub(r"[^a-z0-9]+", "_", str(name).strip().lower()).strip("_")


def detect_columns(df):
    if df is None or df.empty:
        return {k: None for k in COLUMN_ALIASES}
    normalized = {normalize_name(c): c for c in df.columns}
    detected = {}
    for logical_name, aliases in COLUMN_ALIASES.items():
        detected[logical_name] = None
        for alias in aliases:
            alias_norm = normalize_name(alias)
            if alias_norm in normalized:
                detected[logical_name] = normalized[alias_norm]
                break
    return detected


def canonicalize_dataframe(df):
    if df is None or df.empty:
        return pd.DataFrame()

    result = df.copy()
    detected = detect_columns(result)

    for logical_name, actual_name in detected.items():
        if actual_name and logical_name not in result.columns:
            result[logical_name] = result[actual_name]

    return result


# ================================================================
# DATABASE & AUDIT LOG
# ================================================================

def init_database():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS imported_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            imported_at TEXT NOT NULL,
            source_file TEXT,
            data_json TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_time TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS dataset_snapshots (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            name TEXT NOT NULL,
            record_count INTEGER NOT NULL,
            csv_data TEXT NOT NULL,
            notes TEXT
        )
    """)
    conn.commit()
    conn.close()


def add_audit_log(action, details=""):
    timestamp = datetime.now().isoformat(timespec="seconds")
    line = f"{timestamp} | {action} | {details}\n"

    try:
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass

    try:
        conn = sqlite3.connect(DB_FILE)
        conn.execute(
            "INSERT INTO audit_log (event_time, action, details) VALUES (?, ?, ?)",
            (timestamp, action, details),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def read_audit_log(limit=200):
    if not os.path.exists(DB_FILE):
        return []
    try:
        conn = sqlite3.connect(DB_FILE)
        rows = conn.execute(
            "SELECT id, event_time, action, details FROM audit_log ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        conn.close()
        return [{"id": r[0], "time": r[1], "action": r[2], "details": r[3]} for r in rows]
    except Exception:
        return []


def save_to_database(df, source_file=""):
    if df is None or df.empty:
        return 0

    records = df.where(pd.notna(df), None).to_dict(orient="records")
    conn = sqlite3.connect(DB_FILE)
    conn.executemany(
        """
        INSERT INTO imported_records (imported_at, source_file, data_json)
        VALUES (?, ?, ?)
        """,
        [
            (
                datetime.now().isoformat(timespec="seconds"),
                os.path.basename(source_file) if source_file else "CYBER_VAULT",
                json.dumps(record, default=str),
            )
            for record in records
        ],
    )
    conn.commit()
    conn.close()

    add_audit_log("VAULT_STORE", f"Encrypted & stored {len(df)} telemetry frames")
    return len(df)


def save_snapshot(df, name="NOC Snapshot", notes=""):
    if df is None or df.empty:
        return False
    csv_str = df.to_csv(index=False)
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    conn = sqlite3.connect(DB_FILE)
    conn.execute(
        "INSERT INTO dataset_snapshots (created_at, name, record_count, csv_data, notes) VALUES (?, ?, ?, ?, ?)",
        (timestamp, name, len(df), csv_str, notes)
    )
    conn.commit()
    conn.close()
    add_audit_log("SNAPSHOT_ARCHIVE", f"Archived snapshot '{name}' ({len(df)} frames)")
    return True


def list_snapshots():
    if not os.path.exists(DB_FILE):
        return []
    try:
        conn = sqlite3.connect(DB_FILE)
        rows = conn.execute(
            "SELECT id, created_at, name, record_count, notes FROM dataset_snapshots ORDER BY id DESC"
        ).fetchall()
        conn.close()
        return [
            {"id": r[0], "created_at": r[1], "name": r[2], "record_count": r[3], "notes": r[4]}
            for r in rows
        ]
    except Exception:
        return []


def restore_snapshot(snapshot_id):
    if not os.path.exists(DB_FILE):
        return None
    try:
        conn = sqlite3.connect(DB_FILE)
        row = conn.execute(
            "SELECT csv_data, name FROM dataset_snapshots WHERE id = ?", (snapshot_id,)
        ).fetchone()
        conn.close()
        if not row:
            return None
        import io
        df = pd.read_csv(io.StringIO(row[0]))
        save_current_dataframe(df)
        add_audit_log("SNAPSHOT_RESTORE", f"Restored snapshot '{row[1]}'")
        return df
    except Exception as e:
        print("Restore snapshot error:", e)
        return None


# ================================================================
# FILE & DATA INGESTION
# ================================================================

def list_sqlite_tables(db_path):
    conn = sqlite3.connect(db_path)
    try:
        rows = conn.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%' "
            "ORDER BY name"
        ).fetchall()
        return [row[0] for row in rows]
    finally:
        conn.close()


def _read_sqlite_table(db_path, table_name):
    conn = sqlite3.connect(db_path)
    try:
        return pd.read_sql_query(f'SELECT * FROM "{table_name}"', conn)
    finally:
        conn.close()


def load_data(file_path, table_name=None):
    if not file_path or not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    ext = Path(file_path).suffix.lower()

    if ext == ".csv":
        df = pd.read_csv(file_path)
    elif ext in (".json", ".jsonl"):
        try:
            df = pd.read_json(file_path, lines=(ext == ".jsonl"))
        except ValueError:
            df = pd.read_json(file_path)
    elif ext in (".db", ".sqlite", ".sqlite3"):
        if table_name is None:
            raise ValueError("Table name required for SQLite database.")
        df = _read_sqlite_table(file_path, table_name)
    else:
        raise ValueError("Supported formats: CSV, JSON, JSONL, or SQLite.")

    if df.empty:
        raise ValueError("Ingested file contains no data.")

    df = canonicalize_dataframe(df)
    add_audit_log("INGEST_DATA", f"Ingested {len(df)} telemetry frames from {os.path.basename(file_path)}")
    return df


def get_current_dataframe():
    if not os.path.exists(DATA_FILE):
        return pd.DataFrame()
    try:
        df = pd.read_csv(DATA_FILE)
        return canonicalize_dataframe(df)
    except Exception:
        return pd.DataFrame()


def save_current_dataframe(df):
    if df is not None:
        df.to_csv(DATA_FILE, index=False)


# ================================================================
# RF SPECTRUM & CYBER TELEMETRY MODELING
# ================================================================

def classify_rsrp(rsrp):
    if pd.isna(rsrp):
        return "Unknown"
    try:
        value = float(rsrp)
    except (TypeError, ValueError):
        return "Unknown"

    if value >= -75:
        return "Optimal (5G NR)"
    elif value >= -90:
        return "Stable (LTE)"
    elif value >= -105:
        return "Marginal"
    elif value >= -115:
        return "Degraded"
    return "Critical / Blindspot"


# Cyber Ops Neon Spectrum
RSRP_CATEGORY_COLORS = {
    "Optimal (5G NR)": "#00F2FE",      # Neon Cyber Cyan
    "Stable (LTE)": "#10B981",          # Matrix Emerald
    "Marginal": "#F59E0B",              # Cyber Amber
    "Degraded": "#F97316",              # Laser Orange
    "Critical / Blindspot": "#EF4444",  # Crimson Threat Alert
    "Unknown": "#64748B",               # Dark Steel
}


def analyze_signal_strength(df):
    if df is None or df.empty or "rsrp" not in df.columns:
        return None

    work = df.copy()
    work["rsrp_num"] = pd.to_numeric(work["rsrp"], errors="coerce")
    valid = work.dropna(subset=["rsrp_num"])

    if valid.empty:
        return None

    rsrp_series = valid["rsrp_num"]
    avg_val = float(rsrp_series.mean())
    median_val = float(rsrp_series.median())
    std_val = float(rsrp_series.std()) if len(rsrp_series) > 1 else 0.0
    max_idx = rsrp_series.idxmax()
    min_idx = rsrp_series.idxmin()
    max_row = valid.loc[max_idx]
    min_row = valid.loc[min_idx]

    jitter = float(rsrp_series.diff().abs().mean()) if len(rsrp_series) > 1 else 0.0

    categories = rsrp_series.apply(classify_rsrp).value_counts()
    cat_order = ["Optimal (5G NR)", "Stable (LTE)", "Marginal", "Degraded", "Critical / Blindspot"]
    total_cat = categories.sum()

    category_list = []
    for cat_name in cat_order:
        cnt = int(categories.get(cat_name, 0))
        if cnt > 0 or total_cat > 0:
            category_list.append({
                "name": cat_name,
                "count": cnt,
                "pct": round(cnt / total_cat * 100, 1) if total_cat else 0,
                "color": RSRP_CATEGORY_COLORS.get(cat_name, "#64748B"),
            })

    if "timestamp" in valid.columns:
        valid_sorted = valid.assign(_st=pd.to_datetime(valid["timestamp"], errors="coerce")).sort_values("_st")
    else:
        valid_sorted = valid

    series_data = []
    for i, (_, row) in enumerate(valid_sorted.iterrows()):
        label = str(row.get("timestamp") or f"Frame #{i+1}")
        cell = str(row.get("cell_id") or "NODE_ALPHA")
        tech = str(row.get("radio_type") or "5G_NR")
        val = float(row["rsrp_num"])
        series_data.append({
            "label": label,
            "value": round(val, 1),
            "cell": cell,
            "tech": tech,
            "quality": classify_rsrp(val)
        })

    total_duration_sec = 0
    if "duration" in df.columns:
        dur_series = pd.to_numeric(df["duration"], errors="coerce").dropna()
        total_duration_sec = int(dur_series.sum())

    # Network Security & Signal Integrity Index (0-100%)
    integrity_index = max(15, min(100, int(100 - (abs(avg_val + 68) * 1.25))))

    return {
        "total_records": len(df),
        "valid": len(valid),
        "avg": round(avg_val, 1),
        "median": round(median_val, 1),
        "std_dev": round(std_val, 2),
        "jitter": round(jitter, 2),
        "integrity_index": integrity_index,
        "max": round(float(max_row["rsrp_num"]), 1),
        "max_cell": str(max_row.get("cell_id", "—")),
        "min": round(float(min_row["rsrp_num"]), 1),
        "min_cell": str(min_row.get("cell_id", "—")),
        "total_duration_sec": total_duration_sec,
        "total_duration_fmt": format_duration(total_duration_sec),
        "categories": category_list,
        "series": series_data[-120:],
    }


def format_duration(seconds):
    if not seconds:
        return "0s"
    m, s = divmod(int(seconds), 60)
    h, m = divmod(m, 60)
    if h > 0:
        return f"{h}h {m}m {s}s"
    if m > 0:
        return f"{m}m {s}s"
    return f"{s}s"


def build_sparkline_points(series, width=720, height=140, pad=12):
    if not series:
        return "", None, None
    values = [p["value"] for p in series]
    lo, hi = min(values), max(values)
    span = (hi - lo) or 1.0
    n = len(values)
    step = (width - 2 * pad) / max(n - 1, 1)

    points = []
    for i, v in enumerate(values):
        x = pad + i * step
        y = pad + (1 - (v - lo) / span) * (height - 2 * pad)
        points.append(f"{x:.1f},{y:.1f}")

    return " ".join(points), round(lo, 1), round(hi, 1)


def analyze_network_types(df):
    if df is None or df.empty or "radio_type" not in df.columns:
        return []
    distribution = df["radio_type"].dropna().astype(str).str.strip().str.upper().value_counts()
    total = distribution.sum()
    tech_colors = {
        "5G": "#00F2FE",       # Cyber Cyan
        "5G NR": "#00F2FE",
        "LTE": "#3B82F6",      # Electric Blue
        "4G": "#3B82F6",
        "3G": "#F59E0B",       # Cyber Amber
        "UMTS": "#F59E0B",
        "2G": "#EF4444",       # Crimson Alert
        "GSM": "#EF4444",
    }
    return [
        {
            "type": k,
            "count": int(v),
            "pct": round(float(v) / total * 100, 1) if total else 0,
            "color": tech_colors.get(k, "#8B5CF6"),
        }
        for k, v in distribution.items()
    ]


def analyze_call_types(df):
    if df is None or df.empty or "call_type" not in df.columns:
        return []
    distribution = df["call_type"].dropna().astype(str).str.strip().str.upper().value_counts()
    total = distribution.sum()
    call_colors = {
        "INCOMING": "#10B981",  # Matrix Green
        "OUTGOING": "#00F2FE",  # Cyber Cyan
        "MISSED": "#EF4444",    # Threat Crimson
        "DROPPED": "#F59E0B",   # Warning Amber
        "REJECTED": "#8B5CF6",
    }
    return [
        {
            "type": k,
            "count": int(v),
            "pct": round(float(v) / total * 100, 1) if total else 0,
            "color": call_colors.get(k, "#64748B"),
        }
        for k, v in distribution.items()
    ]


def top_cells(df, top_n=6):
    if df is None or df.empty or "cell_id" not in df.columns or "rsrp" not in df.columns:
        return []
    work = df.copy()
    work["rsrp_num"] = pd.to_numeric(work["rsrp"], errors="coerce")
    work = work.dropna(subset=["rsrp_num", "cell_id"])
    if work.empty:
        return []

    grouped = work.groupby("cell_id").agg(
        avg_rsrp=("rsrp_num", "mean"),
        count=("rsrp_num", "count"),
        min_rsrp=("rsrp_num", "min"),
        max_rsrp=("rsrp_num", "max"),
        tech=("radio_type", lambda s: s.iloc[0] if "radio_type" in work.columns and len(s) else "5G_NR"),
    ).sort_values("count", ascending=False).head(top_n).reset_index()

    return [
        {
            "cell_id": str(row["cell_id"]),
            "avg": round(float(row["avg_rsrp"]), 1),
            "count": int(row["count"]),
            "min": round(float(row["min_rsrp"]), 1),
            "max": round(float(row["max_rsrp"]), 1),
            "tech": str(row.get("tech", "5G_NR")),
            "quality": classify_rsrp(row["avg_rsrp"]),
        }
        for _, row in grouped.iterrows()
    ]


def extract_geo_data(df):
    if df is None or df.empty or "latitude" not in df.columns or "longitude" not in df.columns:
        return []

    work = df.copy()
    work["lat_num"] = pd.to_numeric(work["latitude"], errors="coerce")
    work["lon_num"] = pd.to_numeric(work["longitude"], errors="coerce")
    if "rsrp" in work.columns:
        work["rsrp_num"] = pd.to_numeric(work["rsrp"], errors="coerce")
    else:
        work["rsrp_num"] = None

    valid = work.dropna(subset=["lat_num", "lon_num"])
    valid = valid[(valid["lat_num"].between(-90, 90)) & (valid["lon_num"].between(-180, 180))]

    if valid.empty:
        return []

    geo_points = []
    for _, row in valid.iterrows():
        rsrp_val = float(row["rsrp_num"]) if pd.notna(row["rsrp_num"]) else None
        quality = classify_rsrp(rsrp_val) if rsrp_val is not None else "Unknown"
        geo_points.append({
            "lat": float(row["lat_num"]),
            "lng": float(row["lon_num"]),
            "rsrp": rsrp_val,
            "quality": quality,
            "color": RSRP_CATEGORY_COLORS.get(quality, "#00F2FE"),
            "cell_id": str(row.get("cell_id", "NODE_UNKNOWN")),
            "tech": str(row.get("radio_type", "5G")),
            "call_type": str(row.get("call_type", "DATA_STREAM")),
            "phone": str(row.get("phone_number", "MSISDN_ENCRYPTED")),
            "timestamp": str(row.get("timestamp", "")),
        })

    return geo_points


# ================================================================
# CYBERSECURITY & NETWORK ANOMALY THREAT DETECTION
# ================================================================

def detect_anomalies(df):
    """
    Cybersecurity & RF Threat Intelligence Rules:
    1. CRITICAL_SPECTRUM_DEATH: Severe attenuation (RSRP <= -120 dBm) -> potential jammer or RF shielding.
    2. ABNORMAL_RF_ATTENUATION: Rapid signal delta >= 20 dB -> possible sudden RF anomaly.
    3. INTER_RAT_DOWNGRADE_ATTACK: 5G/LTE forced to 2G/3G -> possible IMSI Catcher / Fake Base Station downgrade.
    4. CALL_DROP_RF_CORRELATION: Interrupted transmission coinciding with RF degradation.
    """
    if df is None or df.empty:
        return []

    work = df.copy()
    anomalies = []

    if "timestamp" in work.columns:
        work["_sort_time"] = pd.to_datetime(work["timestamp"], errors="coerce")
        work = work.sort_values("_sort_time", na_position="last").reset_index(drop=True)

    if "rsrp" in work.columns:
        work["rsrp_num"] = pd.to_numeric(work["rsrp"], errors="coerce")

        for idx, row in work.iterrows():
            val = row["rsrp_num"]
            ts = str(row.get("timestamp", f"Frame #{idx+1}"))
            cell = str(row.get("cell_id", "NODE_UNKNOWN"))
            tech = str(row.get("radio_type", "5G"))

            if pd.notna(val):
                if val <= -120:
                    anomalies.append({
                        "id": f"ano-{idx}-crit",
                        "timestamp": ts,
                        "cell_id": cell,
                        "type": "CRITICAL_BLINDSPOT",
                        "severity": "HIGH",
                        "details": f"Severe RF collapse ({val:.1f} dBm) on {tech} cell sector ({cell}).",
                        "recommendation": "Investigate potential high-density obstruction, tower outage, or RF jamming interference.",
                    })
                elif val <= -110:
                    anomalies.append({
                        "id": f"ano-{idx}-weak",
                        "timestamp": ts,
                        "cell_id": cell,
                        "type": "WEAK_COVERAGE_BORDER",
                        "severity": "MEDIUM",
                        "details": f"Sub-threshold signal boundary ({val:.1f} dBm) detected near {cell}.",
                        "recommendation": "Packet loss / voice jitter risk. Verify neighbor cell handover hysteresis margins.",
                    })

                if "call_type" in work.columns:
                    ct = str(row.get("call_type", "")).upper()
                    dur = row.get("duration", None)
                    dur_val = float(dur) if pd.notna(dur) and str(dur).replace(".","").isdigit() else None
                    if (ct in ["MISSED", "DROPPED"] or dur_val == 0) and val <= -110:
                        anomalies.append({
                            "id": f"ano-{idx}-drop",
                            "timestamp": ts,
                            "cell_id": cell,
                            "type": "CALL_DROP_RF_FAULT",
                            "severity": "HIGH",
                            "details": f"Transmission terminated ({ct}) under degraded RF conditions ({val:.1f} dBm).",
                            "recommendation": "RF uplink failure verified. Check handover timer parameters and carrier power control.",
                        })

        valid = work.dropna(subset=["rsrp_num"]).reset_index(drop=True)
        if len(valid) > 1:
            diffs = valid["rsrp_num"].diff().abs()
            for i in range(1, len(valid)):
                delta = diffs.iloc[i]
                if delta >= 20:
                    curr_val = valid.loc[i, "rsrp_num"]
                    prev_val = valid.loc[i-1, "rsrp_num"]
                    ts = str(valid.loc[i].get("timestamp", f"Frame #{i+1}"))
                    cell = str(valid.loc[i].get("cell_id", "NODE_UNKNOWN"))
                    anomalies.append({
                        "id": f"ano-jump-{i}",
                        "timestamp": ts,
                        "cell_id": cell,
                        "type": "RAPID_RF_ATTENUATION",
                        "severity": "MEDIUM",
                        "details": f"Sudden swing of {delta:.1f} dB (from {prev_val:.1f} to {curr_val:.1f} dBm).",
                        "recommendation": "Rapid shielding entry or multipath fading. Verify shadowing margins.",
                    })

    if "radio_type" in work.columns:
        radio = work["radio_type"].astype(str).str.strip().str.upper()
        for i in range(1, len(work)):
            curr_rat = radio.iloc[i]
            prev_rat = radio.iloc[i-1]
            if curr_rat != prev_rat and curr_rat != "NAN" and prev_rat != "NAN":
                is_downgrade = (
                    ("5G" in prev_rat and "3G" in curr_rat) or
                    ("5G" in prev_rat and "2G" in curr_rat) or
                    ("LTE" in prev_rat and "3G" in curr_rat) or
                    ("LTE" in prev_rat and "2G" in curr_rat)
                )
                severity = "HIGH" if is_downgrade else "LOW"
                anomalies.append({
                    "id": f"ano-rat-{i}",
                    "timestamp": str(work.iloc[i].get("timestamp", f"Frame #{i+1}")),
                    "cell_id": str(work.iloc[i].get("cell_id", "NODE_UNKNOWN")),
                    "type": "INTER_RAT_DOWNGRADE" if is_downgrade else "CELL_HANDOVER",
                    "severity": severity,
                    "details": f"RAT transition detected: {prev_rat} → {curr_rat}.",
                    "recommendation": "Security Advisory: Potential Rogue Base Station / CSFB downgrade attack. Verify ciphering indicators." if is_downgrade else "Standard cell-to-cell mobility handover.",
                })

    add_audit_log("ANOMALY_SCAN", f"Identified {len(anomalies)} telemetry anomalies")
    return anomalies


SEVERITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}


def sorted_anomalies(anomalies):
    return sorted(anomalies, key=lambda a: SEVERITY_ORDER.get(a.get("severity", "LOW"), 9))


# ================================================================
# SYNTHETIC TELECOM & CYBERSECURITY DATA GENERATOR
# ================================================================

def generate_synthetic_telecom_data(num_records=50, profile="5G_URBAN_DRIVE", include_geo=True):
    base_time = datetime.now() - timedelta(minutes=num_records * 4)
    records = []

    cells = [
        {"id": "GNB-NR-101 (Sector Alpha)", "tech": "5G", "base_rsrp": -72, "lac": "TAC-0x501", "lat": 19.0760, "lon": 72.8777},
        {"id": "GNB-NR-102 (Sector Bravo)", "tech": "5G", "base_rsrp": -75, "lac": "TAC-0x501", "lat": 19.0775, "lon": 72.8795},
        {"id": "ENB-LTE-201 (Sector Gamma)", "tech": "LTE", "base_rsrp": -86, "lac": "TAC-0x502", "lat": 19.0792, "lon": 72.8812},
        {"id": "ENB-LTE-202 (Sector Delta)", "tech": "LTE", "base_rsrp": -94, "lac": "TAC-0x502", "lat": 19.0815, "lon": 72.8835},
        {"id": "BTS-3G-009 (Legacy Fallback)", "tech": "3G", "base_rsrp": -116, "lac": "LAC-0x108", "lat": 19.0838, "lon": 72.8858},
        {"id": "GNB-NR-103 (Sector Echo)", "tech": "5G", "base_rsrp": -69, "lac": "TAC-0x503", "lat": 19.0860, "lon": 72.8880},
    ]

    current_cell_idx = 0
    current_rsrp = -74.0
    targets = ["NODE-0134", "NODE-0198", "SEC-GATEWAY", "ENDPOINT-0176", "NODE-0143", "DISPATCH-007"]

    for i in range(num_records):
        step_time = base_time + timedelta(minutes=i * 3 + random.randint(0, 45) / 60.0)

        if random.random() < 0.28 and current_cell_idx < len(cells) - 1:
            current_cell_idx = (current_cell_idx + 1) % len(cells)

        active_cell = cells[current_cell_idx]

        noise = random.gauss(0, 3.2)
        is_deep_fade = (i in [12, 27, 39])
        if is_deep_fade:
            current_rsrp = -119.0 + random.uniform(-4, 2)
        else:
            target_rsrp = active_cell["base_rsrp"] + noise
            current_rsrp = current_rsrp * 0.42 + target_rsrp * 0.58

        current_rsrp = max(-130.0, min(-55.0, current_rsrp))

        call_types = ["INCOMING", "OUTGOING", "MISSED"]
        weights = [0.45, 0.45, 0.10] if current_rsrp > -110 else [0.20, 0.20, 0.60]
        c_type = random.choices(call_types, weights=weights)[0]
        dur = 0 if c_type == "MISSED" else random.randint(20, 380)

        lat_jitter = active_cell["lat"] + (i * 0.00028) + random.uniform(-0.0001, 0.0001)
        lon_jitter = active_cell["lon"] + (i * 0.00028) + random.uniform(-0.0001, 0.0001)

        records.append({
            "timestamp": step_time.strftime("%Y-%m-%d %H:%M:%S"),
            "call_type": c_type,
            "phone_number": random.choice(targets),
            "duration": dur,
            "cell_id": active_cell["id"],
            "lac": active_cell["lac"],
            "mcc": 404,
            "mnc": 45,
            "radio_type": active_cell["tech"],
            "rsrp": round(current_rsrp, 1),
            "latitude": round(lat_jitter, 5) if include_geo else None,
            "longitude": round(lon_jitter, 5) if include_geo else None,
        })

    df = pd.DataFrame(records)
    return canonicalize_dataframe(df)


# ================================================================
# REPORT GENERATION & EXPORTS
# ================================================================

def export_csv_report(df, filename="telecom_security_report.csv"):
    path = os.path.join(REPORTS_DIR, filename)
    df.to_csv(path, index=False)
    add_audit_log("EXPORT_CSV", filename)
    return path


def export_json_report(df, filename="telecom_security_report.json"):
    path = os.path.join(REPORTS_DIR, filename)
    records = df.where(pd.notna(df), None).to_dict(orient="records")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, default=str)
    add_audit_log("EXPORT_JSON", filename)
    return path


def export_html_report(df, filename="executive_security_report.html"):
    path = os.path.join(REPORTS_DIR, filename)
    work = df.copy()

    signal_stats = analyze_signal_strength(work)
    networks = analyze_network_types(work)
    cells = top_cells(work, top_n=6)
    anomalies = detect_anomalies(work)

    total_records = len(work)
    avg_rsrp = f"{signal_stats['avg']} dBm" if signal_stats else "N/A"
    integrity_index = signal_stats["integrity_index"] if signal_stats else 88

    anomaly_rows = ""
    if anomalies:
        for a in anomalies[:20]:
            sev = a["severity"].lower()
            sev_color = "#EF4444" if sev == "high" else ("#F59E0B" if sev == "medium" else "#00F2FE")
            anomaly_rows += f"""
            <tr style="border-bottom:1px solid #1E293B;">
              <td style="padding:12px 14px;"><span style="color:{sev_color}; font-weight:800; font-size:11px; border:1px solid {sev_color}; padding:2px 8px; border-radius:100px; text-transform:uppercase;">{a['severity']}</span></td>
              <td style="padding:12px 14px; font-family:monospace; color:#00F2FE; font-weight:700;">{a['type']}</td>
              <td style="padding:12px 14px; color:#CBD5E1;">{a['details']}<br><span style="font-size:11.5px; color:#94A3B8;">→ Advisory: {a.get('recommendation', '')}</span></td>
              <td style="padding:12px 14px; font-family:monospace; color:#64748B; font-size:12px;">{a['timestamp']}</td>
            </tr>
            """
    else:
        anomaly_rows = '<tr><td colspan="4" style="padding:20px; text-align:center; color:#10B981; font-weight:700;">🛡️ Zero RF Anomalies Detected. Spectrum integrity fully verified.</td></tr>'

    html_content = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>{APP_BRAND} Cyber Telecom Security Report</title>
<style>
  * {{ box-sizing: border-box; }}
  body {{ font-family: 'Segoe UI', system-ui, -apple-system, sans-serif; background: #080B10; color: #E2E8F0; margin: 0; padding: 36px 20px; }}
  .container {{ max-width: 1040px; margin: 0 auto; background: #0D111A; border: 1px solid #1E293B; border-radius: 16px; padding: 36px; box-shadow: 0 20px 40px rgba(0,0,0,0.7); }}
  .header {{ display: flex; justify-content: space-between; align-items: flex-start; border-bottom: 1px solid #1E293B; padding-bottom: 24px; margin-bottom: 28px; }}
  .brand {{ font-size: 24px; font-weight: 800; color: #00F2FE; letter-spacing: -0.02em; }}
  .sub {{ font-size: 13px; color: #64748B; margin-top: 4px; }}
  .cards {{ display: grid; grid-template-columns: repeat(auto-fit, minmax(180px, 1fr)); gap: 16px; margin-bottom: 28px; }}
  .card {{ background: #131926; border: 1px solid #222F46; border-radius: 12px; padding: 18px; text-align: center; }}
  .card-label {{ font-size: 11px; text-transform: uppercase; color: #94A3B8; font-weight: 700; letter-spacing: 0.05em; }}
  .card-value {{ font-size: 28px; font-weight: 800; color: #F8FAFC; margin-top: 6px; }}
  .section-title {{ font-size: 17px; font-weight: 800; color: #F8FAFC; margin: 32px 0 16px; }}
  table {{ width: 100%; border-collapse: collapse; font-size: 13px; }}
  th {{ background: #131926; color: #94A3B8; font-size: 11px; text-transform: uppercase; padding: 12px 14px; text-align: left; border-bottom: 1px solid #222F46; }}
  .footer {{ margin-top: 40px; padding-top: 20px; border-top: 1px solid #1E293B; font-size: 11px; color: #64748B; text-align: center; }}
</style>
</head>
<body>
<div class="container">
  <div class="header">
    <div>
      <div class="brand">⚡ {APP_BRAND}</div>
      <div class="sub">Cyber Telecom Security &amp; Network Intelligence Report</div>
    </div>
    <div style="text-align:right; font-family:monospace; font-size:12px; color:#94A3B8;">
      Generated: {datetime.now().strftime("%Y-%m-%d %H:%M:%S")}<br>
      {total_records} Total Telemetry Frames
    </div>
  </div>

  <div class="cards">
    <div class="card">
      <div class="card-label">Total Frames</div>
      <div class="card-value">{total_records}</div>
    </div>
    <div class="card">
      <div class="card-label">Spectrum Integrity</div>
      <div class="card-value" style="color:#00F2FE;">{integrity_index}%</div>
    </div>
    <div class="card">
      <div class="card-label">Average RSRP</div>
      <div class="card-value" style="color:#10B981;">{avg_rsrp}</div>
    </div>
    <div class="card">
      <div class="card-label">Threat Alerts</div>
      <div class="card-value" style="color:{'#EF4444' if anomalies else '#10B981'};">{len(anomalies)}</div>
    </div>
  </div>

  <div class="section-title">🚨 RF Threat Ledger &amp; Anomaly Analysis ({len(anomalies)})</div>
  <table style="border:1px solid #1E293B; border-radius:10px; overflow:hidden;">
    <thead>
      <tr>
        <th>Severity</th>
        <th>Threat Class</th>
        <th>Forensic Details &amp; Security Advisory</th>
        <th>Timestamp</th>
      </tr>
    </thead>
    <tbody>
      {anomaly_rows}
    </tbody>
  </table>

  <div class="footer">
    Compiled autonomously by {APP_BRAND} v{APP_VERSION}. Authorized network security audit only.
  </div>
</div>
</body>
</html>"""

    with open(path, "w", encoding="utf-8") as f:
        f.write(html_content)

    add_audit_log("EXPORT_HTML", filename)
    return path


def delete_report(filename):
    clean_name = os.path.basename(filename)
    path = os.path.join(REPORTS_DIR, clean_name)
    if os.path.exists(path):
        os.remove(path)
        add_audit_log("DELETE_REPORT", clean_name)
        return True
    return False


def df_to_records(df):
    if df is None or df.empty:
        return [], []
    columns = list(df.columns)
    records = df.fillna("").astype(object).to_dict(orient="records")
    return columns, records
