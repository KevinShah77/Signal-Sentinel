"""
SIGNALSENTINEL — Mobile Network & Call Log Analysis Tool (Flask Web App)

Full-stack web application for analyzing authorized call-log and mobile-network-signal exports.
Includes interactive Chart.js analytics, Leaflet.js cell coverage maps, real-time live telemetry,
rule-based telecom anomaly diagnostics, instant sample loaders, synthetic data generator,
and executive report exports.
"""

import os
import uuid
import json
import pandas as pd
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, send_from_directory, jsonify
)
from werkzeug.utils import secure_filename

import core
import live_monitor

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
app.secret_key = os.environ.get("TRACKER_SECRET_KEY", "signalsentinel-telecom-secret-key-2026")
app.config["MAX_CONTENT_LENGTH"] = 64 * 1024 * 1024  # 64 MB

ALLOWED_EXTENSIONS = {"csv", "json", "jsonl", "db", "sqlite", "sqlite3"}

core.init_database()


@app.context_processor
def inject_globals():
    df = core.get_current_dataframe()
    anomalies = core.detect_anomalies(df) if not df.empty else []
    return {
        "app_name": core.APP_NAME,
        "app_version": core.APP_VERSION,
        "app_brand": core.APP_BRAND,
        "has_active_data": not df.empty,
        "total_active_records": len(df),
        "total_active_alerts": len(anomalies),
    }


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def rsrp_bars(value):
    try:
        v = float(value)
    except (TypeError, ValueError):
        return 0
    if v >= -80:
        return 4
    if v >= -95:
        return 3
    if v >= -105:
        return 2
    if v >= -115:
        return 1
    return 0


app.jinja_env.filters["rsrp_bars"] = rsrp_bars


# ============================================================
# DASHBOARD
# ============================================================

@app.route("/")
def dashboard():
    df = core.get_current_dataframe()
    has_data = not df.empty

    signal = core.analyze_signal_strength(df) if has_data else None
    networks = core.analyze_network_types(df) if has_data else []
    call_types = core.analyze_call_types(df) if has_data else []
    cells = core.top_cells(df) if has_data else []
    anomalies = core.detect_anomalies(df) if has_data else []
    geo_points = core.extract_geo_data(df) if has_data else []
    live_status = live_monitor.get_status()
    audit_logs = core.read_audit_log(limit=8)
    snapshots = core.list_snapshots()

    spark_points, spark_lo, spark_hi = (None, None, None)
    if signal and signal.get("series"):
        spark_points, spark_lo, spark_hi = core.build_sparkline_points(signal["series"], width=720, height=130)

    return render_template(
        "dashboard.html",
        has_data=has_data,
        total_records=len(df),
        signal=signal,
        networks=networks,
        call_types=call_types,
        cells=cells,
        anomaly_count=len(anomalies),
        top_anomalies=core.sorted_anomalies(anomalies)[:6],
        geo_points=geo_points,
        has_geo=len(geo_points) > 0,
        live_status=live_status,
        audit_logs=audit_logs,
        snapshots=snapshots,
        spark_points=spark_points,
        spark_lo=spark_lo,
        spark_hi=spark_hi,
    )


# ============================================================
# IMPORT & SAMPLE DATASET LOADERS
# ============================================================

@app.route("/import", methods=["GET", "POST"])
def import_data():
    if request.method == "POST":
        file = request.files.get("data_file")

        if not file or file.filename == "":
            flash("Please choose a file to import.", "error")
            return redirect(url_for("import_data"))

        if not allowed_file(file.filename):
            flash("Unsupported file type. Use .csv, .json, .jsonl, or SQLite database (.db, .sqlite, .sqlite3).", "error")
            return redirect(url_for("import_data"))

        filename = secure_filename(file.filename)
        ext = filename.rsplit(".", 1)[1].lower()

        if ext in {"db", "sqlite", "sqlite3"}:
            token = uuid.uuid4().hex
            saved_path = os.path.join(core.UPLOAD_DIR, f"{token}_{filename}")
            file.save(saved_path)

            try:
                tables = core.list_sqlite_tables(saved_path)
            except Exception as exc:
                flash(f"Error reading SQLite database: {exc}", "error")
                if os.path.exists(saved_path):
                    os.remove(saved_path)
                return redirect(url_for("import_data"))

            if not tables:
                flash("No user tables found in this SQLite database.", "error")
                if os.path.exists(saved_path):
                    os.remove(saved_path)
                return redirect(url_for("import_data"))

            if len(tables) == 1:
                return _finish_sqlite_import(saved_path, tables[0])

            return render_template(
                "import_table_select.html",
                filename=filename,
                token=os.path.basename(saved_path),
                tables=tables,
            )

        # CSV / JSON / JSONL
        temp_path = os.path.join(core.DATA_DIR, f"_upload_{filename}")
        file.save(temp_path)
        try:
            df = core.load_data(temp_path)
        except Exception as exc:
            flash(f"Error loading file: {exc}", "error")
            return redirect(url_for("import_data"))
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

        core.save_current_dataframe(df)
        flash(f"Data loaded successfully — {len(df)} records imported from '{filename}'.", "success")
        return redirect(url_for("dashboard"))

    snapshots = core.list_snapshots()
    return render_template("import.html", snapshots=snapshots)


@app.route("/import/table", methods=["POST"])
def import_table():
    token = request.form.get("token", "")
    table = request.form.get("table", "")
    saved_path = os.path.join(core.UPLOAD_DIR, secure_filename(token))

    if not os.path.exists(saved_path):
        flash("Upload expired — please upload the file again.", "error")
        return redirect(url_for("import_data"))

    return _finish_sqlite_import(saved_path, table)


def _finish_sqlite_import(saved_path, table_name):
    try:
        df = core.load_data(saved_path, table_name=table_name)
    except Exception as exc:
        flash(f"Error loading table: {exc}", "error")
        return redirect(url_for("import_data"))
    finally:
        if os.path.exists(saved_path):
            os.remove(saved_path)

    core.save_current_dataframe(df)
    flash(f"Data loaded successfully — {len(df)} records imported from table '{table_name}'.", "success")
    return redirect(url_for("dashboard"))


# ============================================================
# REST API: SAMPLES & SYNTHETIC DATA
# ============================================================

@app.route("/api/load-sample/<sample_name>", methods=["POST"])
def load_sample_dataset(sample_name):
    """1-Click loader for bundled sample datasets."""
    try:
        if sample_name == "basic":
            path = os.path.join(BASE_DIR, "sample_call_data.csv")
            df = core.load_data(path)
            core.save_current_dataframe(df)
            msg = f"Loaded standard sample dataset ({len(df)} records)."
        elif sample_name == "geo_5g":
            path = os.path.join(core.SAMPLE_DIR, "sample_geo_5g.csv")
            df = core.load_data(path)
            core.save_current_dataframe(df)
            msg = f"Loaded 5G & Geo Telecom dataset ({len(df)} records with coordinates)."
        elif sample_name == "sqlite_call_logs":
            path = os.path.join(core.SAMPLE_DIR, "sample_geo_5g.sqlite")
            df = core.load_data(path, table_name="call_logs")
            core.save_current_dataframe(df)
            msg = f"Loaded SQLite 'call_logs' table ({len(df)} records)."
        elif sample_name == "sqlite_network_events":
            path = os.path.join(core.SAMPLE_DIR, "sample_geo_5g.sqlite")
            df = core.load_data(path, table_name="network_events")
            core.save_current_dataframe(df)
            msg = f"Loaded SQLite 'network_events' table ({len(df)} records with custom schema)."
        else:
            return jsonify({"success": False, "error": "Unknown sample identifier"}), 400

        flash(msg, "success")
        return jsonify({"success": True, "message": msg, "count": len(df)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/generate-synthetic", methods=["POST"])
def generate_synthetic():
    """Generates realistic drive-test data on demand."""
    try:
        data = request.get_json(silent=True) or {}
        num_records = int(data.get("count", 45))
        profile = data.get("profile", "5G_URBAN_DRIVE")
        include_geo = bool(data.get("include_geo", True))

        num_records = max(10, min(500, num_records))
        df = core.generate_synthetic_telecom_data(num_records=num_records, profile=profile, include_geo=include_geo)
        core.save_current_dataframe(df)

        msg = f"Generated {len(df)} synthetic {profile} telemetry records!"
        flash(msg, "success")
        return jsonify({"success": True, "message": msg, "count": len(df)})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500


@app.route("/api/clear-data", methods=["POST"])
def clear_data():
    """Clear active working dataset."""
    if os.path.exists(core.DATA_FILE):
        os.remove(core.DATA_FILE)
    core.add_audit_log("DATA_CLEARED", "User cleared active working dataset")
    flash("Workspace cleared. Ready for new import.", "success")
    return redirect(url_for("dashboard"))


# ============================================================
# RECORDS
# ============================================================

@app.route("/records")
def records():
    df = core.get_current_dataframe()
    if not df.empty and "timestamp" in df.columns:
        df = df.assign(_s=pd.to_datetime(df["timestamp"], errors="coerce"))
        df = df.sort_values("_s", ascending=False).drop(columns=["_s"])
    columns, rows = core.df_to_records(df)
    schema_map = core.detect_columns(df) if not df.empty else {}
    return render_template(
        "records.html",
        columns=columns,
        rows=rows,
        schema_map=schema_map,
        title="All Telemetry Records",
        empty=df.empty,
    )


# ============================================================
# ANALYZE & VISUALIZATIONS
# ============================================================

@app.route("/analyze")
def analyze():
    df = core.get_current_dataframe()
    signal = core.analyze_signal_strength(df) if not df.empty else None
    networks = core.analyze_network_types(df) if not df.empty else []
    call_types = core.analyze_call_types(df) if not df.empty else []
    cells = core.top_cells(df, top_n=8) if not df.empty else []
    geo_points = core.extract_geo_data(df) if not df.empty else []

    spark_points, spark_lo, spark_hi = (None, None, None)
    if signal and signal.get("series"):
        spark_points, spark_lo, spark_hi = core.build_sparkline_points(signal["series"], width=720, height=140)

    return render_template(
        "analyze.html",
        empty=df.empty,
        signal=signal,
        networks=networks,
        call_types=call_types,
        cells=cells,
        geo_points=geo_points,
        has_geo=len(geo_points) > 0,
        spark_points=spark_points,
        spark_lo=spark_lo,
        spark_hi=spark_hi,
    )


# ============================================================
# ALERTS & ANOMALIES
# ============================================================

@app.route("/alerts")
def alerts():
    df = core.get_current_dataframe()
    anomalies = core.sorted_anomalies(core.detect_anomalies(df)) if not df.empty else []
    counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for a in anomalies:
        sev = a.get("severity", "LOW")
        counts[sev] = counts.get(sev, 0) + 1
    return render_template("alerts.html", empty=df.empty, anomalies=anomalies, counts=counts)


# ============================================================
# REPORTS & SNAPSHOTS
# ============================================================

@app.route("/reports", methods=["GET", "POST"])
def reports():
    if request.method == "POST":
        df = core.get_current_dataframe()
        if df.empty:
            flash("No data loaded to export.", "error")
            return redirect(url_for("reports"))

        fmt = request.form.get("format", "html")
        filename = request.form.get("filename", "").strip()

        try:
            if fmt == "csv":
                filename = filename or "telecom_report.csv"
                if not filename.lower().endswith(".csv"):
                    filename += ".csv"
                path = core.export_csv_report(df, secure_filename(filename))
            elif fmt == "json":
                filename = filename or "telecom_report.json"
                if not filename.lower().endswith(".json"):
                    filename += ".json"
                path = core.export_json_report(df, secure_filename(filename))
            elif fmt == "html":
                filename = filename or "executive_analysis_report.html"
                if not filename.lower().endswith(".html"):
                    filename += ".html"
                path = core.export_html_report(df, secure_filename(filename))
            else:
                flash("Unknown report format requested.", "error")
                return redirect(url_for("reports"))
        except Exception as exc:
            flash(f"Error exporting report: {exc}", "error")
            return redirect(url_for("reports"))

        flash(f"Report generated successfully: {os.path.basename(path)}", "success")
        return redirect(url_for("reports"))

    files = sorted(os.listdir(core.REPORTS_DIR)) if os.path.isdir(core.REPORTS_DIR) else []
    reports_info = []
    for f in files:
        full = os.path.join(core.REPORTS_DIR, f)
        if os.path.isfile(full):
            reports_info.append({
                "name": f,
                "size_kb": round(os.path.getsize(full) / 1024, 1),
                "is_html": f.lower().endswith(".html"),
            })

    snapshots = core.list_snapshots()
    audit_logs = core.read_audit_log(limit=40)

    return render_template("reports.html", reports=reports_info, snapshots=snapshots, audit_logs=audit_logs)


@app.route("/reports/<path:filename>")
def download_report(filename):
    return send_from_directory(core.REPORTS_DIR, secure_filename(filename), as_attachment=True)


@app.route("/reports/<path:filename>/view")
def view_report(filename):
    if not filename.lower().endswith(".html"):
        return redirect(url_for("download_report", filename=filename))
    return send_from_directory(core.REPORTS_DIR, secure_filename(filename))


@app.route("/reports/<path:filename>/delete", methods=["POST"])
def delete_report(filename):
    if core.delete_report(filename):
        flash(f"Deleted report '{filename}'.", "success")
    else:
        flash("Could not delete report.", "error")
    return redirect(url_for("reports"))


@app.route("/database/save", methods=["POST"])
def database_save():
    df = core.get_current_dataframe()
    if df.empty:
        flash("No data in workspace to save.", "error")
    else:
        snapshot_name = request.form.get("snapshot_name", "").strip() or f"Snapshot {len(df)} rows"
        notes = request.form.get("notes", "").strip()
        core.save_to_database(df, "active_workspace")
        core.save_snapshot(df, name=snapshot_name, notes=notes)
        flash(f"Saved {len(df)} records and created SQLite snapshot '{snapshot_name}'.", "success")
    return redirect(url_for("reports"))


@app.route("/database/snapshot/restore/<int:snapshot_id>", methods=["POST"])
def database_snapshot_restore(snapshot_id):
    df = core.restore_snapshot(snapshot_id)
    if df is not None:
        flash(f"Snapshot restored successfully ({len(df)} records active).", "success")
    else:
        flash("Failed to restore snapshot.", "error")
    return redirect(url_for("dashboard"))


# ============================================================
# LIVE TELEMETRY MONITOR
# ============================================================

@app.route("/live", methods=["GET", "POST"])
def live():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "start":
            path = request.form.get("source_path", "").strip().strip('"').strip("'")
            interval = request.form.get("interval", "5").strip()
            try:
                interval_val = max(1, int(interval))
            except ValueError:
                flash("Interval must be a whole number of seconds (minimum 1).", "error")
                return redirect(url_for("live"))

            if not os.path.exists(path):
                flash(f"File path not found on server: {path}", "error")
                return redirect(url_for("live"))

            ext = path.rsplit(".", 1)[-1].lower()
            table_name = None
            if ext in {"db", "sqlite", "sqlite3"}:
                tables = core.list_sqlite_tables(path)
                if not tables:
                    flash("No user tables found in that SQLite database.", "error")
                    return redirect(url_for("live"))
                table_name = tables[0]

            live_monitor.start(path, interval=interval_val, table_name=table_name)
            flash(f"Live monitoring active on {os.path.basename(path)} ({interval_val}s polling).", "success")
        elif action == "stop":
            live_monitor.stop()
            flash("Live monitoring paused.", "success")
        return redirect(url_for("live"))

    df = core.get_current_dataframe()
    signal = core.analyze_signal_strength(df) if not df.empty else None
    return render_template("live.html", status=live_monitor.get_status(), signal=signal)


@app.route("/live/status")
def live_status():
    df = core.get_current_dataframe()
    signal = core.analyze_signal_strength(df) if not df.empty else None
    st = live_monitor.get_status()
    st["series"] = signal["series"][-30:] if signal and "series" in signal else []
    st["avg_rsrp"] = signal["avg"] if signal else None
    return jsonify(st)


# ============================================================
# API DATA EXPORT
# ============================================================

@app.route("/api/data")
def api_data():
    df = core.get_current_dataframe()
    columns, rows = core.df_to_records(df)
    return jsonify({"columns": columns, "rows": rows, "count": len(rows)})


@app.route("/api/stats")
def api_stats():
    df = core.get_current_dataframe()
    return jsonify({
        "signal": core.analyze_signal_strength(df) if not df.empty else None,
        "networks": core.analyze_network_types(df) if not df.empty else [],
        "call_types": core.analyze_call_types(df) if not df.empty else [],
        "cells": core.top_cells(df) if not df.empty else [],
        "anomalies": core.detect_anomalies(df) if not df.empty else [],
        "geo": core.extract_geo_data(df) if not df.empty else [],
    })


@app.route("/sample-data")
def sample_data():
    """Serve bundled sample CSV file."""
    return send_from_directory(BASE_DIR, "sample_call_data.csv", as_attachment=True)


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
