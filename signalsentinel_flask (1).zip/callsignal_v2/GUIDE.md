# 🧭 Guide: From Clone to First Analysis

This is the walkthrough version of [README.md](README.md) — follow it top
to bottom the first time you set the project up. If you just want the
short version, the README's Quick Start section covers the same commands.

> ℹ️ This file is about **setting the project up**. Once it's running, the
> app has its own in-app **`/guide`** page that explains every feature —
> use that one while you're actually using the tool.

---

## 1. Before you start

You'll need:

- **Python 3.9 or newer** — check with `python --version` (or `python3 --version`)
- **pip** — check with `pip --version`
- **git** (to clone the repo) — optional if you downloaded a zip instead

Don't have Python? Grab it from [python.org/downloads](https://www.python.org/downloads/).

---

## 2. Get the code

**Option A — clone with git:**

```bash
git clone https://github.com/<your-username>/signalsentinel.git
cd signalsentinel
```

**Option B — downloaded a zip:** unzip it, then `cd` into the folder it created.

---

## 3. Create a virtual environment (recommended)

Keeps this project's dependencies separate from everything else on your
machine.

```bash
python -m venv venv
```

Activate it:

```bash
# macOS / Linux
source venv/bin/activate

# Windows (PowerShell)
venv\Scripts\Activate.ps1

# Windows (Command Prompt)
venv\Scripts\activate.bat
```

You'll know it worked if your terminal prompt now starts with `(venv)`.

---

## 4. Install dependencies

```bash
pip install -r requirements.txt
```

This installs Flask and pandas — that's the whole dependency list. No
`matplotlib`, no `tkinter`, no build step.

---

## 5. Run the app

```bash
python app.py
```

You should see Flask's startup log, something like:

```
 * Running on http://127.0.0.1:5000
 * Running on http://0.0.0.0:5000
```

Open **http://localhost:5000** in your browser. The dashboard loads
directly — there's no login screen.

---

## 6. Take it for a spin with sample data

1. Click **+ Import Data** in the top bar.
2. Choose **`sample_call_data.csv`** (included in the repo root).
3. Once it's imported, click through each page:
   - **Dashboard** — the overview you land on
   - **Records** — the full imported table
   - **Analyze** — signal strength, network distribution, top cells
   - **Alerts** — anomalies detected from the sample data
   - **Reports** — try exporting a CSV, JSON, and HTML report
   - **Live** — read what it does; you don't need to start it to explore the UI
   - **Guide** — the in-app feature reference

---

## 7. Try it with your own data

Any CSV, JSON, JSON Lines, or SQLite file works, as long as it's data you
own or are authorized to analyze. You don't need to rename any columns
first — see [README.md → Supported Data & Column Detection](README.md#-supported-data--column-detection)
for the list of naming conventions that are recognized automatically.

If your file uses column names that *aren't* recognized, the data still
imports fine — you just won't see values in fields like RSRP-based charts
or alerts until a recognizable signal/timestamp/cell column is present.

---

## 8. Common issues

| Problem | Likely fix |
|---|---|
| `command not found: python` | Try `python3` instead of `python` |
| `ModuleNotFoundError: No module named 'flask'` | Your virtual environment isn't activated, or step 4 was skipped |
| `Address already in use` on port 5000 | Something else is using port 5000. Run `python app.py` after editing the last line of `app.py` to use a different port, e.g. `app.run(debug=True, host="0.0.0.0", port=5050)` |
| Live Monitor says "File not found on the server" | The path must exist on the machine *running* `app.py`, not your local machine if you're accessing it remotely. Use an absolute path |
| Uploaded file imports but charts are empty | Your file's columns don't match a recognized alias for `rsrp`/`cell_id`/`radio_type` — the raw data still imports and is viewable under Records |
| Report download does nothing | Check the `reports/` folder was created and is writable — it's created automatically on first export |

Still stuck? Open an [issue](../../issues) with your OS, Python version,
and the exact error message.

---

## 9. Making changes / contributing

Once you're comfortable running the app:

1. Read [CONTRIBUTING.md](CONTRIBUTING.md) for branch naming, commit style, and PR expectations.
2. Make your changes.
3. Re-run through step 6 above as a manual smoke test — there's no automated test suite yet (see the [Roadmap](README.md#-roadmap)), so a quick click-through catches most regressions.
4. Open a pull request.

---

## 10. Where things live (quick map)

| I want to... | Look in... |
|---|---|
| Change a page's layout or copy | `templates/*.html` |
| Change colors, fonts, spacing | `static/style.css` |
| Add/change a route or form handling | `app.py` |
| Change how columns are detected, or add an analysis/anomaly rule | `core.py` |
| Change how Live Monitor polls files | `live_monitor.py` |

---

That's it — you're set up. Enjoy exploring your data. 📡
