# Security Policy

## Scope

SignalSentinel is a **local-first** tool intended to run on `localhost` for
a single analyst. It has no built-in authentication and is **not** designed
to be exposed directly to the public internet. If you deploy it beyond your
own machine, you are responsible for putting appropriate access controls
(a reverse proxy with auth, a VPN, a firewall rule, etc.) in front of it.

## Reporting a Vulnerability

If you find a security issue — for example, a path traversal in file
import/export, a way to read files outside the intended directories, or an
injection vulnerability — please **do not** open a public GitHub issue.

Instead:

1. Open a [private security advisory](../../security/advisories/new) on
   this repository (GitHub → Security → Advisories → "Report a
   vulnerability"), **or**
2. If that's not available, open an issue titled `Security: please
   contact` with no technical details, and a maintainer will follow up to
   arrange a private channel.

Please include:

- A description of the issue and its potential impact
- Steps to reproduce (a minimal example is ideal)
- Any suggested fix, if you have one

We'll do our best to acknowledge reports within a few days and keep you
updated as a fix is developed.

## Supported Versions

This is a young, actively-developed project without formal version
branches yet. Security fixes will be applied to the `main` branch; once
tagged releases exist, this section will be updated with a support table.

## Known Areas of Caution

A few things worth keeping in mind if you're auditing or extending this
code:

- **File uploads** (`/import`) are restricted by extension and use
  `secure_filename`, but any change to upload handling should be reviewed
  for path traversal.
- **Live Monitor** (`/live`) reads an arbitrary server-side file path
  supplied via a form field — this is by design (it's meant to watch a
  file *you* choose on the machine running the app), but it means the app
  should never be exposed to untrusted users without additional access
  control in front of it.
- **`TRACKER_SECRET_KEY`** defaults to a placeholder value for local
  development — always set a real secret via the environment variable
  before running anywhere other than `localhost` (see `.env.example`).
