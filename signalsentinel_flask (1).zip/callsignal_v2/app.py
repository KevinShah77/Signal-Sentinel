"""
SIGNALSENTINEL — Mobile Network & Call Log Analysis Tool (Flask Web App)

Ported from call_signal_tracker_v2.py. All analysis logic lives in core.py;
the background poller lives in live_monitor.py. This is a local, single-user
tool with no login step, matching the desktop GUI dashboard it's based on.

IMPORTANT:
    This program does not intercept calls, communications, SIM traffic, or
    another person's device. Use only data you own or are explicitly
    authorized to analyze.
"""

import os
import uuid

import pandas as pd
from flask import (
    Flask, render_template, request, redirect, url_for,
    flash, send_from_directory, jsonify
)
from werkzeug.utils import secure_filename

import core
import live_monitor

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

app = Flask(__name__)
app.secret_key = os.environ.get("TRACKER_SECRET_KEY", "dev-only-secret-change-me")
app.config["MAX_CONTENT_LENGTH"] = 32 * 1024 * 1024  # 32 MB

ALLOWED_EXTENSIONS = {"csv", "json", "jsonl", "db", "sqlite", "sqlite3"}

core.init_database()


@app.context_processor
def inject_globals():
    return {
        "app_name": core.APP_NAME,
        "app_version": core.APP_VERSION,
        "app_brand": core.APP_BRAND,
    }


def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def rsrp_bars(value):
    try:
        v = float(value)
    except (TypeError, ValueError):
        return 0
    if v >= -80:
        return 4
    if v >= -95:
        return 3
    if v >= -105:
        return 2
    if v >= -115:
        return 1
    return 0


app.jinja_env.filters["rsrp_bars"] = rsrp_bars


# ============================================================
# DASHBOARD
# ============================================================

@app.route("/")
def dashboard():
    df = core.get_current_dataframe()
    has_data = not df.empty

    signal = core.analyze_signal_strength(df) if has_data else None
    networks = core.analyze_network_types(df) if has_data else []
    cells = core.top_cells(df) if has_data else []
    anomalies = core.detect_anomalies(df) if has_data else []
    live_status = live_monitor.get_status()

    return render_template(
        "dashboard.html",
        has_data=has_data,
        total_records=len(df),
        signal=signal,
        networks=networks,
        cells=cells,
        anomaly_count=len(anomalies),
        top_anomalies=core.sorted_anomalies(anomalies)[:5],
        live_status=live_status,
    )


# ============================================================
# IMPORT
# ============================================================

@app.route("/import", methods=["GET", "POST"])
def import_data():
    if request.method == "POST":
        file = request.files.get("data_file")

        if not file or file.filename == "":
            flash("Please choose a file to import.", "error")
            return redirect(url_for("import_data"))

        if not allowed_file(file.filename):
            flash("Unsupported file type. Use .csv, .json, .jsonl, or a SQLite database.", "error")
            return redirect(url_for("import_data"))

        filename = secure_filename(file.filename)
        ext = filename.rsplit(".", 1)[1].lower()

        if ext in {"db", "sqlite", "sqlite3"}:
            token = uuid.uuid4().hex
            saved_path = os.path.join(core.UPLOAD_DIR, f"{token}_{filename}")
            file.save(saved_path)

            try:
                tables = core.list_sqlite_tables(saved_path)
            except Exception as exc:
                flash(f"Error reading SQLite database: {exc}", "error")
                os.remove(saved_path)
                return redirect(url_for("import_data"))

            if not tables:
                flash("No user tables found in this SQLite database.", "error")
                os.remove(saved_path)
                return redirect(url_for("import_data"))

            if len(tables) == 1:
                return _finish_sqlite_import(saved_path, tables[0])

            return render_template(
                "import_table_select.html",
                filename=filename,
                token=os.path.basename(saved_path),
                tables=tables,
            )

        # CSV / JSON / JSONL — load directly
        temp_path = os.path.join(core.DATA_DIR, f"_upload_{filename}")
        file.save(temp_path)
        try:
            df = core.load_data(temp_path)
        except Exception as exc:
            flash(f"Error loading file: {exc}", "error")
            return redirect(url_for("import_data"))
        finally:
            if os.path.exists(temp_path):
                os.remove(temp_path)

        core.save_current_dataframe(df)
        flash(f"Data loaded successfully — {len(df)} records imported.", "success")
        return redirect(url_for("dashboard"))

    return render_template("import.html")


@app.route("/import/table", methods=["POST"])
def import_table():
    token = request.form.get("token", "")
    table = request.form.get("table", "")
    saved_path = os.path.join(core.UPLOAD_DIR, secure_filename(token))

    if not os.path.exists(saved_path):
        flash("Upload expired — please choose the file again.", "error")
        return redirect(url_for("import_data"))

    return _finish_sqlite_import(saved_path, table)


def _finish_sqlite_import(saved_path, table_name):
    try:
        df = core.load_data(saved_path, table_name=table_name)
    except Exception as exc:
        flash(f"Error loading table: {exc}", "error")
        return redirect(url_for("import_data"))
    finally:
        if os.path.exists(saved_path):
            os.remove(saved_path)

    core.save_current_dataframe(df)
    flash(f"Data loaded successfully — {len(df)} records imported from '{table_name}'.", "success")
    return redirect(url_for("dashboard"))


@app.route("/database/save", methods=["POST"])
def database_save():
    df = core.get_current_dataframe()
    if df.empty:
        flash("No data to save.", "error")
    else:
        count = core.save_to_database(df, "current_data")
        flash(f"{count} records saved to local SQLite storage.", "success")
    return redirect(url_for("dashboard"))


# ============================================================
# RECORDS
# ============================================================

@app.route("/records")
def records():
    df = core.get_current_dataframe()
    if not df.empty and "timestamp" in df.columns:
        df = df.assign(_s=pd.to_datetime(df["timestamp"], errors="coerce"))
        df = df.sort_values("_s", ascending=False).drop(columns=["_s"])
    columns, rows = core.df_to_records(df)
    return render_template("records.html", columns=columns, rows=rows, title="All Records", message=None)


# ============================================================
# ANALYZE
# ============================================================

@app.route("/analyze")
def analyze():
    df = core.get_current_dataframe()
    signal = core.analyze_signal_strength(df) if not df.empty else None
    networks = core.analyze_network_types(df) if not df.empty else []
    cells = core.top_cells(df) if not df.empty else []

    spark_points, spark_lo, spark_hi = (None, None, None)
    if signal and signal.get("series"):
        spark_points, spark_lo, spark_hi = core.build_sparkline_points(signal["series"])

    return render_template(
        "analyze.html",
        empty=df.empty,
        signal=signal,
        networks=networks,
        cells=cells,
        spark_points=spark_points,
        spark_lo=spark_lo,
        spark_hi=spark_hi,
    )


# ============================================================
# ANOMALIES + ALERTS
# ============================================================

@app.route("/alerts")
def alerts():
    df = core.get_current_dataframe()
    anomalies = core.sorted_anomalies(core.detect_anomalies(df)) if not df.empty else []
    counts = {"HIGH": 0, "MEDIUM": 0, "LOW": 0}
    for a in anomalies:
        counts[a["severity"]] = counts.get(a["severity"], 0) + 1
    return render_template("alerts.html", empty=df.empty, anomalies=anomalies, counts=counts)


# ============================================================
# REPORTS
# ============================================================

@app.route("/reports", methods=["GET", "POST"])
def reports():
    if request.method == "POST":
        df = core.get_current_dataframe()
        if df.empty:
            flash("No data to export.", "error")
            return redirect(url_for("reports"))

        fmt = request.form.get("format", "csv")
        filename = request.form.get("filename", "").strip()

        try:
            if fmt == "csv":
                filename = filename or "report.csv"
                if not filename.lower().endswith(".csv"):
                    filename += ".csv"
                path = core.export_csv_report(df, secure_filename(filename))
            elif fmt == "json":
                filename = filename or "report.json"
                if not filename.lower().endswith(".json"):
                    filename += ".json"
                path = core.export_json_report(df, secure_filename(filename))
            elif fmt == "html":
                filename = filename or "analysis_report.html"
                if not filename.lower().endswith(".html"):
                    filename += ".html"
                path = core.export_html_report(df, secure_filename(filename))
            else:
                flash("Unknown report format.", "error")
                return redirect(url_for("reports"))
        except Exception as exc:
            flash(f"Error exporting report: {exc}", "error")
            return redirect(url_for("reports"))

        flash(f"Report exported: {os.path.basename(path)}", "success")
        return redirect(url_for("reports"))

    files = sorted(os.listdir(core.REPORTS_DIR)) if os.path.isdir(core.REPORTS_DIR) else []
    reports_info = []
    for f in files:
        full = os.path.join(core.REPORTS_DIR, f)
        reports_info.append({
            "name": f,
            "size_kb": round(os.path.getsize(full) / 1024, 1),
        })
    return render_template("reports.html", reports=reports_info)


@app.route("/reports/<path:filename>")
def download_report(filename):
    return send_from_directory(core.REPORTS_DIR, filename, as_attachment=True)


@app.route("/reports/<path:filename>/view")
def view_report(filename):
    if not filename.lower().endswith(".html"):
        return redirect(url_for("download_report", filename=filename))
    return send_from_directory(core.REPORTS_DIR, filename)


# ============================================================
# LIVE MONITOR
# ============================================================

@app.route("/live", methods=["GET", "POST"])
def live():
    if request.method == "POST":
        action = request.form.get("action")
        if action == "start":
            path = request.form.get("source_path", "").strip().strip('"').strip("'")
            interval = request.form.get("interval", "5").strip()
            try:
                interval_val = int(interval)
            except ValueError:
                flash("Interval must be a whole number of seconds.", "error")
                return redirect(url_for("live"))

            if not os.path.exists(path):
                flash(f"File not found on the server: {path}", "error")
                return redirect(url_for("live"))

            ext = path.rsplit(".", 1)[-1].lower()
            table_name = None
            if ext in {"db", "sqlite", "sqlite3"}:
                tables = core.list_sqlite_tables(path)
                if not tables:
                    flash("No user tables found in that SQLite database.", "error")
                    return redirect(url_for("live"))
                table_name = tables[0]

            live_monitor.start(path, interval=interval_val, table_name=table_name)
            flash(f"Live monitoring started on {os.path.basename(path)}.", "success")
        elif action == "stop":
            live_monitor.stop()
            flash("Live monitoring stopped.", "success")
        return redirect(url_for("live"))

    return render_template("live.html", status=live_monitor.get_status())


@app.route("/live/status")
def live_status():
    return jsonify(live_monitor.get_status())


@app.route("/sample-data")
def sample_data():
    """Serve a small bundled sample CSV so users can try the app instantly."""
    return send_from_directory(BASE_DIR, "sample_call_data.csv", as_attachment=True)


@app.route("/guide")
def guide():
    return render_template("guide.html")


if __name__ == "__main__":
    app.run(debug=True, host="0.0.0.0", port=5000)
