"""
core.py — data logic for the Call & Signal Tracker web app.

Ported from call_signal_tracker_v2.py: generic column detection, signal /
network analysis, rule-based anomaly detection, and CSV/JSON/HTML report
generation. This module has no Flask or Tkinter dependency — it's pure
pandas/sqlite logic so it can be tested on its own.
"""

import os
import re
import json
import sqlite3
from datetime import datetime
from pathlib import Path

import pandas as pd

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.path.join(BASE_DIR, "data")
REPORTS_DIR = os.path.join(BASE_DIR, "reports")
LOGS_DIR = os.path.join(BASE_DIR, "logs")

os.makedirs(DATA_DIR, exist_ok=True)
os.makedirs(REPORTS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

DATA_FILE = os.path.join(DATA_DIR, "call_data.csv")
DB_FILE = os.path.join(DATA_DIR, "tracker.db")
AUDIT_FILE = os.path.join(LOGS_DIR, "audit.log")
UPLOAD_DIR = os.path.join(DATA_DIR, "uploads")
os.makedirs(UPLOAD_DIR, exist_ok=True)

APP_NAME = "Mobile Network & Call Log Analysis Tool"
APP_BRAND = "SignalSentinel"
APP_VERSION = "2.0"


# ================================================================
# GENERIC COLUMN DETECTION
# ================================================================

COLUMN_ALIASES = {
    "timestamp": [
        "timestamp", "time", "datetime", "date_time", "date",
        "event_time", "call_time", "created_at", "recorded_at",
    ],
    "call_type": [
        "call_type", "type", "direction", "call_direction",
        "event_type", "call_status",
    ],
    "phone_number": [
        "phone_number", "phone", "number", "msisdn", "caller",
        "caller_number", "callee", "callee_number", "contact",
    ],
    "duration": [
        "duration", "duration_sec", "duration_seconds", "call_duration",
        "seconds", "length",
    ],
    "cell_id": [
        "cell_id", "cellid", "cell", "eci", "ecid", "enodeb",
        "enodeb_id", "gnodeb", "gnodeb_id",
    ],
    "lac": ["lac", "location_area_code"],
    "mcc": ["mcc", "mobile_country_code"],
    "mnc": ["mnc", "mobile_network_code"],
    "radio_type": [
        "radio_type", "network_type", "network", "technology",
        "radio", "rat", "access_technology",
    ],
    "rsrp": [
        "rsrp", "signal_strength", "signal", "signal_dbm",
        "rsrp_dbm", "reference_signal_received_power",
    ],
    "latitude": ["latitude", "lat"],
    "longitude": ["longitude", "lon", "lng"],
}


def normalize_name(name):
    return re.sub(r"[^a-z0-9]+", "_", str(name).strip().lower()).strip("_")


def detect_columns(df):
    """Map each logical field name to the actual source column, or None."""
    normalized = {normalize_name(c): c for c in df.columns}
    detected = {}
    for logical_name, aliases in COLUMN_ALIASES.items():
        detected[logical_name] = None
        for alias in aliases:
            alias_norm = normalize_name(alias)
            if alias_norm in normalized:
                detected[logical_name] = normalized[alias_norm]
                break
    return detected


def canonicalize_dataframe(df):
    """Add canonical helper columns while preserving every original column."""
    if df is None or df.empty:
        return pd.DataFrame()

    result = df.copy()
    detected = detect_columns(result)

    for logical_name, actual_name in detected.items():
        if actual_name and logical_name not in result.columns:
            result[logical_name] = result[actual_name]

    return result


# ================================================================
# AUDIT LOG
# ================================================================

def init_database():
    conn = sqlite3.connect(DB_FILE)
    cur = conn.cursor()
    cur.execute("""
        CREATE TABLE IF NOT EXISTS imported_records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            imported_at TEXT NOT NULL,
            source_file TEXT,
            data_json TEXT NOT NULL
        )
    """)
    cur.execute("""
        CREATE TABLE IF NOT EXISTS audit_log (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_time TEXT NOT NULL,
            action TEXT NOT NULL,
            details TEXT
        )
    """)
    conn.commit()
    conn.close()


def add_audit_log(action, details=""):
    timestamp = datetime.now().isoformat(timespec="seconds")
    line = f"{timestamp} | {action} | {details}\n"

    try:
        with open(AUDIT_FILE, "a", encoding="utf-8") as f:
            f.write(line)
    except OSError:
        pass

    try:
        conn = sqlite3.connect(DB_FILE)
        conn.execute(
            "INSERT INTO audit_log (event_time, action, details) VALUES (?, ?, ?)",
            (timestamp, action, details),
        )
        conn.commit()
        conn.close()
    except Exception:
        pass


def read_audit_log(limit=200):
    """Return the most recent audit entries, newest first."""
    if not os.path.exists(DB_FILE):
        return []
    try:
        conn = sqlite3.connect(DB_FILE)
        rows = conn.execute(
            "SELECT event_time, action, details FROM audit_log "
            "ORDER BY id DESC LIMIT ?",
            (limit,),
        ).fetchall()
        conn.close()
        return [{"time": r[0], "action": r[1], "details": r[2]} for r in rows]
    except Exception:
        return []


def save_to_database(df, source_file=""):
    """Persist the complete DataFrame to SQLite without assuming a fixed schema."""
    if df is None or df.empty:
        return 0

    records = df.where(pd.notna(df), None).to_dict(orient="records")
    conn = sqlite3.connect(DB_FILE)
    conn.executemany(
        """
        INSERT INTO imported_records (imported_at, source_file, data_json)
        VALUES (?, ?, ?)
        """,
        [
            (
                datetime.now().isoformat(timespec="seconds"),
                os.path.basename(source_file) if source_file else "",
                json.dumps(record, default=str),
            )
            for record in records
        ],
    )
    conn.commit()
    conn.close()

    add_audit_log("DATABASE_SAVE", f"{len(df)} records from {os.path.basename(source_file)}")
    return len(df)


# ================================================================
# GENERIC FILE / DATABASE IMPORT
# ================================================================

def list_sqlite_tables(db_path):
    conn = sqlite3.connect(db_path)
    try:
        rows = conn.execute(
            "SELECT name FROM sqlite_master "
            "WHERE type='table' AND name NOT LIKE 'sqlite_%' "
            "ORDER BY name"
        ).fetchall()
        return [row[0] for row in rows]
    finally:
        conn.close()


def _read_sqlite_table(db_path, table_name):
    conn = sqlite3.connect(db_path)
    try:
        return pd.read_sql_query(f'SELECT * FROM "{table_name}"', conn)
    finally:
        conn.close()


def load_data(file_path, table_name=None):
    """
    Import CSV, JSON, JSON Lines, or a SQLite database table.
    All source columns are preserved; canonical aliases are added on top.
    """
    if not file_path or not os.path.exists(file_path):
        raise FileNotFoundError(f"File not found: {file_path}")

    ext = Path(file_path).suffix.lower()

    if ext == ".csv":
        df = pd.read_csv(file_path)
    elif ext in (".json", ".jsonl"):
        try:
            df = pd.read_json(file_path, lines=(ext == ".jsonl"))
        except ValueError:
            df = pd.read_json(file_path)
    elif ext in (".db", ".sqlite", ".sqlite3"):
        if table_name is None:
            raise ValueError("A table name is required for SQLite sources.")
        df = _read_sqlite_table(file_path, table_name)
    else:
        raise ValueError("Unsupported format. Use CSV, JSON, JSONL, or SQLite.")

    if df.empty:
        raise ValueError("No data found in the file.")

    df = canonicalize_dataframe(df)
    add_audit_log("IMPORT", f"{len(df)} records from {os.path.basename(file_path)}")
    return df


def get_current_dataframe():
    if not os.path.exists(DATA_FILE):
        return pd.DataFrame()
    try:
        return pd.read_csv(DATA_FILE)
    except Exception:
        return pd.DataFrame()


def save_current_dataframe(df):
    df.to_csv(DATA_FILE, index=False)


# ================================================================
# SIGNAL / NETWORK ANALYSIS
# ================================================================

def classify_rsrp(rsrp):
    if pd.isna(rsrp):
        return "Unknown"
    value = float(rsrp)
    if value >= -70:
        return "Excellent"
    elif value >= -90:
        return "Good"
    elif value >= -110:
        return "Fair"
    elif value >= -120:
        return "Poor"
    return "Very Poor"


RSRP_CATEGORY_COLORS = {
    "Excellent": "#2DD9C4",
    "Good": "#67C7B8",
    "Fair": "#FFB454",
    "Poor": "#FF8F5E",
    "Very Poor": "#FF6B6B",
    "Unknown": "#5D7089",
}


def analyze_signal_strength(df):
    if df.empty or "rsrp" not in df.columns:
        return None

    work = df.copy()
    work["rsrp"] = pd.to_numeric(work["rsrp"], errors="coerce")
    valid = work.dropna(subset=["rsrp"])

    if valid.empty:
        return None

    max_row = valid.loc[valid["rsrp"].idxmax()]
    min_row = valid.loc[valid["rsrp"].idxmin()]
    categories = valid["rsrp"].apply(classify_rsrp).value_counts()
    total_cat = categories.sum()

    return {
        "total_records": len(df),
        "valid": len(valid),
        "avg": round(float(valid["rsrp"].mean()), 2),
        "max": round(float(max_row["rsrp"]), 2),
        "max_cell": max_row.get("cell_id", "—") if "cell_id" in valid.columns else "—",
        "min": round(float(min_row["rsrp"]), 2),
        "min_cell": min_row.get("cell_id", "—") if "cell_id" in valid.columns else "—",
        "categories": [
            {
                "name": name,
                "count": int(count),
                "pct": round(float(count) / total_cat * 100, 1) if total_cat else 0,
                "color": RSRP_CATEGORY_COLORS.get(name, "#5D7089"),
            }
            for name, count in categories.items()
        ],
        "series": [
            {"label": str(row.get("timestamp", i)), "value": float(row["rsrp"])}
            for i, (_, row) in enumerate(valid.iterrows())
        ][-60:],  # cap points for a readable chart
    }


def build_sparkline_points(series, width=680, height=160, pad=10):
    """Turn a list of {'value': float} points into an SVG polyline string."""
    if not series:
        return "", None, None
    values = [p["value"] for p in series]
    lo, hi = min(values), max(values)
    span = (hi - lo) or 1.0
    n = len(values)
    step = (width - 2 * pad) / max(n - 1, 1)

    points = []
    for i, v in enumerate(values):
        x = pad + i * step
        y = pad + (1 - (v - lo) / span) * (height - 2 * pad)
        points.append(f"{x:.1f},{y:.1f}")

    return " ".join(points), round(lo, 1), round(hi, 1)


def analyze_network_types(df):
    if df.empty or "radio_type" not in df.columns:
        return []
    distribution = df["radio_type"].astype(str).value_counts(dropna=False)
    total = distribution.sum()
    return [
        {
            "type": k,
            "count": int(v),
            "pct": round(float(v) / total * 100, 1) if total else 0,
        }
        for k, v in distribution.items()
    ]


def top_cells(df, top_n=5):
    if df.empty or "cell_id" not in df.columns or "rsrp" not in df.columns:
        return []
    work = df.copy()
    work["rsrp"] = pd.to_numeric(work["rsrp"], errors="coerce")
    work = work.dropna(subset=["rsrp", "cell_id"])
    if work.empty:
        return []
    result = (
        work.groupby("cell_id")["rsrp"]
        .agg(["mean", "count", "min", "max"])
        .sort_values("mean", ascending=False)
        .head(top_n)
        .reset_index()
    )
    return [
        {
            "cell_id": row["cell_id"],
            "avg": round(float(row["mean"]), 2),
            "count": int(row["count"]),
            "min": round(float(row["min"]), 2),
            "max": round(float(row["max"]), 2),
        }
        for _, row in result.iterrows()
    ]


# ================================================================
# ANOMALY DETECTION + ALERTS
# ================================================================

def detect_anomalies(df):
    """
    Simple, explainable rules:
    - RSRP <= -110 dBm -> weak signal event
    - sudden large RSRP movement between adjacent records (>= 20 dB)
    - radio/network technology change between adjacent records
    """
    if df.empty:
        return []

    work = df.copy()
    anomalies = []

    if "timestamp" in work.columns:
        work["_sort_time"] = pd.to_datetime(work["timestamp"], errors="coerce")
        work = work.sort_values("_sort_time", na_position="last")

    if "rsrp" in work.columns:
        work["rsrp"] = pd.to_numeric(work["rsrp"], errors="coerce")

        for idx in work.index:
            value = work.at[idx, "rsrp"]
            if pd.notna(value) and value <= -110:
                anomalies.append({
                    "timestamp": work.at[idx, "timestamp"] if "timestamp" in work.columns else "",
                    "type": "WEAK_SIGNAL",
                    "severity": "HIGH" if value <= -120 else "MEDIUM",
                    "details": f"RSRP {value} dBm",
                })

        valid = work.dropna(subset=["rsrp"])
        if len(valid) > 1:
            changes = valid["rsrp"].diff().abs()
            for idx in changes[changes >= 20].index:
                value = valid.loc[idx, "rsrp"]
                anomalies.append({
                    "timestamp": valid.loc[idx, "timestamp"] if "timestamp" in valid.columns else "",
                    "type": "SUDDEN_SIGNAL_CHANGE",
                    "severity": "MEDIUM",
                    "details": f"Large RSRP change; current {value} dBm",
                })

    if "radio_type" in work.columns:
        radio = work["radio_type"].astype(str)
        previous = radio.shift(1)
        for idx in work.index[1:]:
            current = radio.loc[idx]
            old = previous.loc[idx]
            if current != old:
                anomalies.append({
                    "timestamp": work.loc[idx, "timestamp"] if "timestamp" in work.columns else "",
                    "type": "NETWORK_CHANGE",
                    "severity": "LOW",
                    "details": f"{old} -> {current}",
                })

    add_audit_log("ANOMALY_SCAN", f"{len(anomalies)} anomalies")
    return anomalies


SEVERITY_ORDER = {"HIGH": 0, "MEDIUM": 1, "LOW": 2}


def sorted_anomalies(anomalies):
    return sorted(anomalies, key=lambda a: SEVERITY_ORDER.get(a["severity"], 9))


# ================================================================
# REPORT GENERATION
# ================================================================

def export_csv_report(df, filename="report.csv"):
    path = os.path.join(REPORTS_DIR, filename)
    df.to_csv(path, index=False)
    add_audit_log("EXPORT_CSV", path)
    return path


def export_json_report(df, filename="report.json"):
    path = os.path.join(REPORTS_DIR, filename)
    records = df.where(pd.notna(df), None).to_dict(orient="records")
    with open(path, "w", encoding="utf-8") as f:
        json.dump(records, f, indent=2, default=str)
    add_audit_log("EXPORT_JSON", path)
    return path


def export_html_report(df, filename="analysis_report.html"):
    path = os.path.join(REPORTS_DIR, filename)
    work = df.copy()

    if "rsrp" in work.columns:
        work["rsrp"] = pd.to_numeric(work["rsrp"], errors="coerce")

    total = len(work)
    avg = work["rsrp"].mean() if "rsrp" in work.columns else None
    strongest = work["rsrp"].max() if "rsrp" in work.columns else None
    weakest = work["rsrp"].min() if "rsrp" in work.columns else None

    anomalies = detect_anomalies(work)
    anomaly_df = pd.DataFrame(anomalies)

    table = work.to_html(index=False, classes="data-table", border=0)
    anomaly_table = (
        anomaly_df.to_html(index=False, classes="data-table", border=0)
        if not anomaly_df.empty
        else "<p>No rule-based anomalies detected.</p>"
    )

    html_text = f"""<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>{APP_NAME} Report</title>
<style>
body {{ font-family: Arial, sans-serif; background:#f3f3f3; margin:30px; }}
.container {{ max-width:1400px; margin:auto; background:white; padding:25px; }}
.cards {{ display:flex; gap:12px; flex-wrap:wrap; }}
.card {{ border:1px solid #ddd; padding:15px; min-width:160px; }}
.data-table {{ border-collapse:collapse; width:100%; margin-top:15px; }}
.data-table th,.data-table td {{ border:1px solid #ddd; padding:7px; }}
.data-table th {{ background:#eee; }}
small {{ color:#555; }}
</style>
</head>
<body>
<div class="container">
<h1>{APP_NAME} - Analysis Report</h1>
<p>Generated: {datetime.now().isoformat(timespec="seconds")}</p>

<div class="cards">
<div class="card"><b>Total Records</b><br>{total}</div>
<div class="card"><b>Average RSRP</b><br>
{f"{avg:.2f} dBm" if pd.notna(avg) else "N/A"}</div>
<div class="card"><b>Strongest</b><br>
{f"{strongest:.2f} dBm" if pd.notna(strongest) else "N/A"}</div>
<div class="card"><b>Weakest</b><br>
{f"{weakest:.2f} dBm" if pd.notna(weakest) else "N/A"}</div>
<div class="card"><b>Anomalies</b><br>{len(anomaly_df)}</div>
</div>

<h2>Detected Schema</h2>
<pre>{json.dumps(detect_columns(work), indent=2)}</pre>

<h2>Alerts / Anomalies</h2>
{anomaly_table}

<h2>Records</h2>
{table}

<p><small>
This application analyzes authorized/imported datasets. It does not intercept
communications or collect another person's device data.
</small></p>
</div>
</body>
</html>"""

    with open(path, "w", encoding="utf-8") as f:
        f.write(html_text)

    add_audit_log("EXPORT_HTML", path)
    return path


def df_to_records(df):
    if df.empty:
        return [], []
    columns = list(df.columns)
    records = df.fillna("").astype(object).to_dict(orient="records")
    return columns, records
