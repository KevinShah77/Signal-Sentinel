---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: enhancement
---

**What problem would this solve?**
A clear description of what you're trying to do that isn't currently
possible (or is currently awkward).

**Describe the solution you'd like**
What you want to happen.

**Describe alternatives you've considered**
Any alternative solutions or workarounds you've thought about.

**Does this fit the project's scope?**
This tool is intentionally local-first, single-user, and limited to
analyzing authorized/imported datasets (see [README.md](../../README.md#-authorized-use-only)).
Please note if your request would require moving outside that scope.

**Additional context**
Mockups, links, or examples from other tools, if helpful.
