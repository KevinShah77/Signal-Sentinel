---
name: Bug report
about: Something isn't working as expected
title: "[Bug] "
labels: bug
---

**Describe the bug**
A clear, concise description of what's wrong.

**To Reproduce**
Steps to reproduce the behavior:
1. Go to '...' page
2. Click on '...' / import '...'
3. See error

**Expected behavior**
What you expected to happen instead.

**Screenshots**
If applicable, add screenshots to help explain the problem.

**Environment**
- OS: [e.g. macOS 14, Windows 11, Ubuntu 22.04]
- Python version: [e.g. 3.11.4] (`python --version`)
- Browser (if UI-related): [e.g. Chrome 126]

**Error output / traceback**
```
Paste the full terminal output or browser error here
```

**Additional context**
Anything else relevant — sample data shape, file format, etc. (please
don't attach real/sensitive data — a small synthetic example is best).
