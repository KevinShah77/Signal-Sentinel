## What does this PR do?

<!-- A clear, short description of the change. -->

## Why?

<!-- Link a related issue if one exists: Closes #123 -->

## How was this tested?

<!-- Which pages/flows did you click through? Include steps so a reviewer
     can repeat them. There's no automated test suite yet, so a manual
     walkthrough is expected — see GUIDE.md step 6. -->

- [ ] Ran `python app.py` locally with no errors
- [ ] Imported `sample_call_data.csv` (or another dataset) successfully
- [ ] Clicked through the page(s) this change touches
- [ ] Checked the browser console / terminal for new errors or warnings

## Screenshots (if UI changes)

<!-- Before/after screenshots help a lot for template or CSS changes. -->

## Checklist

- [ ] I've read [CONTRIBUTING.md](../CONTRIBUTING.md)
- [ ] I've updated relevant docs (`README.md`, `GUIDE.md`, or the in-app
      `/guide` page) if behavior changed
- [ ] This change keeps the app local-first with no data collection or
      interception, per the project's [authorized-use scope](../README.md#-authorized-use-only)
