# Contributing to SignalSentinel

Thanks for considering a contribution! This is a small, local-first Flask
app, so the process is intentionally lightweight.

## Ground rules

- Be respectful — see the [Code of Conduct](CODE_OF_CONDUCT.md).
- Keep the app's core promise intact: **local-only, no data collection, no
  phone/network interception, authorized-use datasets only.** PRs that move
  toward live interception, remote telemetry, or bypassing the
  authorized-use framing will be declined regardless of how useful they
  might otherwise be.

## Getting set up

Follow [GUIDE.md](GUIDE.md) to get the app running locally before making
changes.

## Workflow

1. **Open an issue first** for anything beyond a small fix — a quick
   discussion avoids duplicated or wasted work.
2. **Fork** the repo and create a branch off `main`:
   ```bash
   git checkout -b feature/short-description
   ```
   Use a prefix that matches the change: `feature/`, `fix/`, `docs/`,
   `refactor/`.
3. **Make your changes**, keeping them focused — one logical change per PR
   is much easier to review than several bundled together.
4. **Smoke-test manually** by running the app and clicking through the
   pages your change touches (import, records, analyze, alerts, reports,
   live monitor). There's no automated test suite yet — see the
   [Roadmap](README.md#-roadmap) if you'd like to help add one.
5. **Commit** with a clear message describing *what* and *why*:
   ```
   Add JSON export of the alert list

   Alerts were only exportable as part of the full HTML report; this adds
   a standalone JSON download from the Alerts page.
   ```
6. **Open a pull request** against `main`, describing:
   - What the change does and why
   - How you tested it (which pages/flows you clicked through)
   - Any follow-up work you're intentionally leaving out of scope

## Code style

- **Python**: follow standard `PEP 8` conventions; keep functions small and
  named for what they do (the existing `core.py` functions are a good
  reference for style/docstrings).
- **Templates**: reuse existing CSS classes in `static/style.css` before
  adding new ones — the design system already covers cards, panels, badges,
  tables, forms, and alerts.
- **No new heavy dependencies** without discussion first — part of the
  point of this project is a lightweight `pip install -r requirements.txt`.

## Reporting bugs

Open an issue with:
- What you did
- What you expected
- What actually happened (include the exact error message/traceback if any)
- Your OS and Python version

## Reporting security issues

Please **do not** open a public issue for security vulnerabilities — see
[SECURITY.md](SECURITY.md) instead.

## Documentation changes

Docs (`README.md`, `GUIDE.md`, the in-app `/guide` page) are treated as
first-class — if your change alters behavior, update the relevant doc in
the same PR.
