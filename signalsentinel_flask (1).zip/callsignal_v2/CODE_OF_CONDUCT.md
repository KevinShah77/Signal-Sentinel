# Code of Conduct

## Our Pledge

We as contributors and maintainers pledge to make participation in this
project a harassment-free experience for everyone, regardless of age, body
size, disability, ethnicity, gender identity and expression, level of
experience, nationality, personal appearance, race, religion, or sexual
identity and orientation.

## Our Standards

Examples of behavior that contributes to a positive environment:

- Using welcoming and inclusive language
- Being respectful of differing viewpoints and experiences
- Gracefully accepting constructive criticism
- Focusing on what is best for the community and the project

Examples of unacceptable behavior:

- Harassment, insults, or derogatory comments, public or private
- Trolling or deliberately inflammatory remarks
- Publishing others' private information without explicit permission
- Any conduct that would reasonably be considered inappropriate in a
  professional setting

## Scope

This Code of Conduct applies within all project spaces (issues, pull
requests, discussions) and in public spaces when an individual is
representing the project.

## Enforcement

Instances of unacceptable behavior may be reported by opening an issue
marked appropriately, or by contacting the maintainers directly if the
report involves sensitive content. All complaints will be reviewed and
investigated, and will result in a response deemed necessary and
appropriate to the circumstances. Maintainers are obligated to maintain
confidentiality regarding the reporter of an incident.

## Attribution

This Code of Conduct is adapted from the
[Contributor Covenant](https://www.contributor-covenant.org/), version 2.1.
