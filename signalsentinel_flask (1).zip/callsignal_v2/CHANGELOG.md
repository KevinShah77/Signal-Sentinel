# Changelog

All notable changes to this project are documented here.
Format loosely follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/).

## [Unreleased]

### Added
- `GUIDE.md` — step-by-step setup/onboarding walkthrough
- `CONTRIBUTING.md`, `CODE_OF_CONDUCT.md`, `SECURITY.md`
- `.gitignore`, `.env.example`
- In-app `/guide` page documenting every feature for end users

### Changed
- Rebranded to **SignalSentinel — Mobile Network & Call Log Analysis Tool**
- Removed login/authentication — the app is local-first and single-user
- Removed Search, Date Filter, dedicated Call Logs page, and the Schema
  display page from the UI (column/schema detection still runs internally)
- Reworked visual design: neutral dark palette, humanist typography, no
  background texture or scan-line animation

## [2.0.0]

### Added
- Flask web UI converted from the original `call_signal_tracker_v2.py`
  CLI/Tkinter tool
- Generic CSV / JSON / JSON Lines / SQLite import with a table picker for
  multi-table databases
- Flexible column detection across common naming conventions
- Records table, Analyze page (signal stats, network distribution, top
  cells, signal-over-time chart)
- Rule-based anomaly detection (weak signal, sudden signal change, network
  change) and an Alerts page
- CSV / JSON / HTML report export with a report history list
- SQLite persistence for the current dataset
- Live Monitor: polls a server-side file path on an interval and
  auto-reloads the dataset when it changes

## [1.0.0]

### Added
- Initial Flask conversion of the original `call_signal_tracker.py`
  command-line tool (import, view, search, filter, basic signal analysis,
  CSV export)
